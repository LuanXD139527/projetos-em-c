#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PRODUTOS 100
#define ARQUIVO_ESTOQUE "estoque.txt"

// Estrutura que representa um produto
typedef struct {
    int id;
    char nome[50];
    float preco;
    int quantidade;
} Produto;

// Protótipos das funções 
void carregarDoArquivo(Produto produtos[], int *total);
void salvarNoArquivo(Produto produtos[], int total);
void cadastrarProduto(Produto produtos[], int *total);
void listarProdutos(Produto produtos[], int total);

int main() {
    Produto produtos[MAX_PRODUTOS];
    int total = 0;
    int opcao;

    // Carrega os dados salvos anteriormente ao iniciar o programa
    carregarDoArquivo(produtos, &total);

    do {
        printf("\n==============================\n");
        printf("    SISTEMA DE ESTOQUE v1.0   \n");
        printf("==============================\n");
        printf("1. Cadastrar Novo Produto\n");
        printf("2. Listar Produtos\n");
        printf("3. Sair\n");
        printf("Escolha uma opcao: ");
        
        if (scanf("%d", &opcao) != 1) {
            printf("Entrada invalida! Tente novamente.\n");
            while (getchar() != '\n'); // Limpa o buffer
            continue;
        }
        while (getchar() != '\n'); // Limpa o '\n' restante do scanf

        switch (opcao) {
            case 1:
                cadastrarProduto(produtos, &total);
                break;
            case 2:
                listarProdutos(produtos, total);
                break;
            case 3:
                printf("\nSalvando dados e encerrando o programa...\n");
                salvarNoArquivo(produtos, total);
                printf("Programa encerrado com sucesso!\n");
                break;
            default:
                printf("\nOpcao invalida! Escolha entre 1 e 3.\n");
        }
    } while (opcao != 3);

    return 0;
}

// Função para cadastrar um produto
void cadastrarProduto(Produto produtos[], int *total) {
    if (*total >= MAX_PRODUTOS) {
        printf("\n[Erro] O estoque esta cheio!\n");
        return;
    }

    Produto p;
    p.id = *total + 1; // ID automático baseado na ordem

    printf("\n--- Cadastro de Produto (ID: %d) ---\n", p.id);
    
    printf("Nome do produto: ");
    fgets(p.nome, sizeof(p.nome), stdin);
    p.nome[strcspn(p.nome, "\n")] = '\0'; // Remove a quebra de linha do final

    printf("Preco (R$): ");
    scanf("%f", &p.preco);

    printf("Quantidade em estoque: ");
    scanf("%d", &p.quantidade);
    while (getchar() != '\n'); // Limpa o buffer

    produtos[*total] = p;
    (*total)++;

    salvarNoArquivo(produtos, *total); // Salva automaticamente após cadastrar
    printf("\nProduto cadastrado e salvo com sucesso!\n");
}

// Função para listar os produtos cadastrados
void listarProdutos(Produto produtos[], int total) {
    if (total == 0) {
        printf("\nNenhum produto cadastrado no momento.\n");
        printf("\nPressione enter para voltar ao menu...");
        getchar(); //Pausa espera o usuario apertar enter
        return;
    }

    printf("\n--- Lista de Produtos no Estoque ---\n");
    printf("%-4s | %-25s | %-10s | %-10s\n", "ID", "Nome", "Preco", "Qtd");
    printf("--------------------------------------------------\n");
    
    for (int i = 0; i < total; i++) {
        printf("%-4d | %-25s | R$ %-7.2f | %-10d\n", 
               produtos[i].id, 
               produtos[i].nome, 
               produtos[i].preco, 
               produtos[i].quantidade);
    }
    printf("--------------------------------------------------\n");
    printf("Pressione enter para voltar ao menu...");
    getchar(); //Espera o usuario apertar enter para continuar
}

// Função para salvar os dados em arquivo de texto
void salvarNoArquivo(Produto produtos[], int total) {
    FILE *file = fopen(ARQUIVO_ESTOQUE, "w");
    if (file == NULL) {
        printf("\n[Erro] Nao foi possivel abrir o arquivo para escrita.\n");
        return;
    }

    for (int i = 0; i < total; i++) {
        fprintf(file, "%d;%s;%.2f;%d\n", 
                produtos[i].id, 
                produtos[i].nome, 
                produtos[i].preco, 
                produtos[i].quantidade);
    }

    fclose(file);
}

// Função para carregar os dados do arquivo ao iniciar
void carregarDoArquivo(Produto produtos[], int *total) {
    FILE *file = fopen(ARQUIVO_ESTOQUE, "r");
    if (file == NULL) {
        // Arquivo ainda não existe, o que é normal na primeira execução
        *total = 0;
        return;
    }

    *total = 0;
    while (fscanf(file, "%d;%49[^;];%f;%d\n", 
                  &produtos[*total].id, 
                  produtos[*total].nome, 
                  &produtos[*total].preco, 
                  &produtos[*total].quantidade) == 4) {
        (*total)++;
        if (*total >= MAX_PRODUTOS) break;
    }

    fclose(file);
}